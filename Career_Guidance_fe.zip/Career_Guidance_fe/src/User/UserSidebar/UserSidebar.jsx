import { useState } from "react"
import { Outlet, useNavigate, useLocation } from "react-router-dom"
import "./UserSidebar.css"
import {MdSchool, MdDashboard, MdAssignment,MdEmojiEvents, MdTrackChanges, MdDescription, MdLogout} from "react-icons/md"

export default function UserSidebar() {
    const navigate = useNavigate()
    const location = useLocation()
    const [showPopup, setShowPopup] = useState(false)
    const user = {
        name: location.state?.name,
        email: location.state?.email
    }
    const menuItems = [
        { icon: <MdDashboard />, name: "Dashboard", path: "/dashboard" },
        { icon: <MdAssignment />, name: "Assessment", path: "/assessment" },
        { icon: <MdEmojiEvents />, name: "Results", path: "/results" },
        { icon: <MdTrackChanges />, name: "Skill Gap", path: "/skillgap" },
        { icon: <MdDescription />, name: "Resume Analyzer", path: "/resume" }
    ]

    return (
        <div className="userSidebar_layout_container">
            <div className="userSidebar_main_container">
                <div className="userSidebar_logo_section">
                    <div className="userSidebar_logo_icon">
                        <MdSchool />
                    </div>
                    <div className="userSidebar_logo_text">
                        CareerGuide AI
                    </div>
                </div>
                <div className="userSidebar_profile_box">
                    <div className="userSidebar_profile_name">
                        {user.name || "Guest"}
                    </div>
                    <div className="userSidebar_profile_email">
                        {user.email || "guest@email.com"}
                    </div>
                </div>
                <div className="userSidebar_menu_container">
                    {menuItems.map((item, index) => (
                        <div
                            key={index}
                            className={`userSidebar_menu_item ${
                                location.pathname === item.path
                                    ? "userSidebar_active"
                                    : ""
                            }`}
                            onClick={() =>
                                navigate(item.path, {
                                    state: user
                                })
                            }
                        >
                            <div className="userSidebar_menu_icon">
                                {item.icon}
                            </div>
                            <div className="userSidebar_menu_text">
                                {item.name}
                            </div>
                        </div>
                    ))}
                </div>
                <div
                    className="userSidebar_logout_section"
                    onClick={() => setShowPopup(true)}
                >
                    <div className="userSidebar_logout_item">
                        <MdLogout />
                        <span>Logout</span>
                    </div>
                </div>
            </div>
            <div className="userSidebar_page_container">
                <Outlet />
            </div>
            {showPopup && (
                <div className="logoutPopup_overlay">
                    <div className="logoutPopup_box">
                        <div className="logoutPopup_title">
                            Logout
                        </div>
                        <div className="logoutPopup_text">
                            Are you sure you want to logout?
                        </div>
                        <div className="logoutPopup_buttons">
                            <div
                                className="logoutPopup_cancel"
                                onClick={() => setShowPopup(false)}
                            >
                                Cancel
                            </div>
                            <div
                                className="logoutPopup_confirm"
                                onClick={() => navigate("/")}
                            >
                                Logout
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}