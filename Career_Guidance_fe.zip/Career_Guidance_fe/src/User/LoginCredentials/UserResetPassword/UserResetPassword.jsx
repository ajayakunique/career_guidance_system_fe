import { useState } from "react"
import "./UserResetPassword.css"
import { MdSchool } from "react-icons/md"
import { useNavigate, useLocation } from "react-router-dom"
import axios from "axios"

export default function UserResetPassword() {
    const navigate = useNavigate()
    const location = useLocation()
    const email = location.state?.email || ""
    const [password, setPassword] = useState("")
    const [confirmPassword, setConfirmPassword] = useState("")
    const [error, setError] = useState("")
    const [success, setSuccess] = useState("")
    const [loading, setLoading] = useState(false)
    const handleReset = async () => {
        if (!password || !confirmPassword) {
            setError("Please fill all fields")
            setSuccess("")
            return
        }
        if (password.length < 4) {
            setError("Password must be at least 4 characters")
            setSuccess("")
            return
        }
        if (password !== confirmPassword) {
            setError("Passwords do not match")
            setSuccess("")
            return
        }
        try {
            setLoading(true)
            setError("")
            setSuccess("")
            const response = await axios.post("http://127.0.0.1:8000/reset-password",{Email: email,Password: password})
            console.log(response.data)
            if (response.data.message === "Password reset successful") {
                setSuccess("Password reset successful!")
                setTimeout(() => {
                    navigate("/")
                }, 1500)
            } else {
                setError(response.data.message)
            }
        } catch (err) {
            console.log(err)
            setError("Something went wrong")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="userReset_main_container">
            <div className="userReset_logo_section">
                <div className="userReset_logo_icon">
                    <MdSchool />
                </div>
                <div className="userReset_logo_text">
                    CareerGuide AI
                </div>
            </div>
            <div className="userReset_card">
                <div className="userReset_title">
                    Reset Password
                </div>
                <div className="userReset_subtitle">
                    Enter your new password
                </div>
                <div className="userReset_form">
                    <label className="userReset_label">
                        New Password
                    </label>
                    <input
                        type="password"
                        placeholder="Enter new password"
                        className="userReset_input"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <label className="userReset_label">
                        Confirm Password
                    </label>
                    <input
                        type="password"
                        placeholder="Confirm password"
                        className="userReset_input"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                    {error && (
                        <div style={{ color: "red", marginBottom: "10px" }}>
                            {error}
                        </div>
                    )}
                    {success && (
                        <div style={{ color: "green", marginBottom: "10px" }}>
                            {success}
                        </div>
                    )}
                    <button
                        className="userReset_button"
                        onClick={handleReset}
                        disabled={loading}
                    >
                        {loading ? "Updating..." : "Reset Password"}
                    </button>
                    <button
                        className="userReset_back_button"
                        onClick={() => navigate("/forgotpassword")}
                    >
                        Back
                    </button>
                </div>
            </div>
        </div>
    )
}