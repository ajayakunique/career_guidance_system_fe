import { useState } from "react"
import { useNavigate } from "react-router-dom"
import "./UserLogin.css"
import { MdSchool } from "react-icons/md"
import axios from "axios"

export default function UserLogin() {
    const navigate = useNavigate()
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [error, setError] = useState("")
    const [loading, setLoading] = useState(false)
    const handleLogin = async () => {
    try {
        setLoading(true)
        setError("")
        const response = await axios.post(
            "http://127.0.0.1:8000/login",
            {
                Email: email,
                Password: password
            }
        )
        if (response.data.message === "Login successful") {
            const user = response.data.user
            navigate("/dashboard", {
                state: {
                    name: user.name,
                    email: user.email
                }
            })
        } else {
            setError(response.data.message)
        }
        } catch (err) {
        setError("Login failed")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="userLogin_main_container">
            <div className="userLogin_logo_section">
                <div className="userLogin_logo_icon">
                    <MdSchool />
                </div>
                <div className="userLogin_logo_text">
                    CareerGuide AI
                </div>
            </div>
            <div className="userLogin_login_card">
                <div className="userLogin_login_title">
                    Welcome back
                </div>
                <div className="userLogin_login_subtitle">
                    Sign in to your account to continue
                </div>
                <div className="userLogin_form_section">
                    <label className="userLogin_label">Email</label>
                    <input
                        type="email"
                        placeholder="john@example.com"
                        className="userLogin_input"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    <label className="userLogin_label">Password</label>
                    <input
                        type="password"
                        placeholder="********"
                        className="userLogin_input"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <div
                        className="userLogin_forgot_password"
                        onClick={() => navigate("/forgotpassword")}
                    >
                        Forgot password?
                    </div>
                    {error && (
                        <div style={{ color: "red", marginBottom: "10px" }}>
                            {error}
                        </div>
                    )}
                    <button
                        className="userLogin_signin_button"
                        onClick={handleLogin}
                        disabled={loading}
                    >
                        {loading ? "Signing in..." : "Sign In"}
                    </button>
                    <div className="userLogin_footer_text">
                        <span>Don't have an account?</span>
                        <div
                            onClick={() => navigate("/signup")}
                            className="userLogin_create_account"
                        >
                            Create account
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}