import { useState } from "react"
import "./UserSignup.css"
import { MdSchool } from "react-icons/md"
import { useNavigate } from "react-router-dom"
import axios from "axios"

export default function UserSignup() {
    const navigate = useNavigate()
    const [formData, setFormData] = useState({
        Full_Name: "",
        Email: "",
        Password: "",
        Degree: "",
        Skills: "",
        Interests: ""
    })
    const [error, setError] = useState("")
    const [success, setSuccess] = useState("")
    const [loading, setLoading] = useState(false)
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        })
    }
    const handleSignup = async () => {
        try {
            const response = await axios.post("http://127.0.0.1:8000/create_new_account", formData)
            console.log(response.data);
            navigate("/")
        }
        catch (error) {
            console.log(error);
        }
    }

    return (
        <div className="userSignup_main_container">
            <div className="userSignup_left_section">
                <div className="userSignup_left_content">
                    <div className="userSignup_brand">
                        <div className="userSignup_brand_icon">
                            <MdSchool />
                        </div>
                        <div className="userSignup_brand_text">
                            CareerGuide AI
                        </div>
                    </div>
                    <div className="userSignup_heading">
                        Start Your Career Journey Today
                    </div>
                    <div className="userSignup_description">
                        Join thousands of students discovering their perfect career path with AI-powered guidance.
                    </div>
                    <img
                        src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f"
                        className="userSignup_image"
                        alt="students"
                    />
                </div>
            </div>
            <div className="userSignup_right_section">
                <div className="userSignup_card">
                    <div className="userSignup_title">
                        Create an account
                    </div>
                    <div className="userSignup_subtitle">
                        Enter your information to get started
                    </div>
                    <div className="userSignup_form">
                        <label>Full Name *</label>
                        <input
                            type="text"
                            name="Full_Name"
                            placeholder="John Doe"
                            className="userSignup_input"
                            onChange={handleChange}
                        />
                        <label>Email *</label>
                        <input
                            type="email"
                            name="Email"
                            placeholder="john@example.com"
                            className="userSignup_input"
                            onChange={handleChange}
                        />
                        <label>Password *</label>
                        <input
                            type="password"
                            name="Password"
                            placeholder="********"
                            className="userSignup_input"
                            onChange={handleChange}
                        />
                        <label>Degree</label>
                        <input
                            type="text"
                            name="Degree"
                            placeholder="Computer Science"
                            className="userSignup_input"
                            onChange={handleChange}
                        />
                        <label>Skills</label>
                        <input
                            type="text"
                            name="Skills"
                            placeholder="JavaScript, Python"
                            className="userSignup_input"
                            onChange={handleChange}
                        />
                        <label>Interests</label>
                        <input
                            type="text"
                            name="Interests"
                            placeholder="AI, Web Dev"
                            className="userSignup_input"
                            onChange={handleChange}
                        />
                        {error && (
                            <div style={{ color: "red", marginBottom: "10px" }}>
                                {error}
                            </div>
                        )}
                        {success && (
                            <div style={{ color: "green", marginBottom: "10px" }}>
                                {success}
                            </div>
                        )}
                        <button
                            className="userSignup_button"
                            onClick={handleSignup}
                            disabled={loading}
                        >
                            {loading ? "Creating..." : "Create Account"}
                        </button>
                        <div className="userSignup_footer">
                            <span>Already have an account?</span>
                            <div
                                onClick={() => navigate("/")}
                                className="userSignup_login_link"
                            >
                                Sign in
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}