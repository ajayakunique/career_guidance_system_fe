import { useState } from "react"
import "./UserForgotPassword.css"
import { MdSchool } from "react-icons/md"
import { useNavigate } from "react-router-dom"
import axios from "axios"

export default function UserForgotPassword() {
    const navigate = useNavigate()
    const [email, setEmail] = useState("")
    const [error, setError] = useState("")
    const [loading, setLoading] = useState(false)
    const handleReset = async () => {
        if (!email) {
            setError("Please enter your email")
            return
        }
        try {
            setLoading(true)
            setError("")
            const response = await axios.post("http://127.0.0.1:8000/forget-password",{Email: email})
            console.log(response.data)
            if (response.data.message === "Email verified") {
                navigate("/resetpassword", { state: { email } })
            } else {
                setError(response.data.message)
            }
        } catch (err) {
            console.log(err)
            setError("Something went wrong")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="userForgot_main_container">
            <div className="userForgot_logo_section">
                <div className="userForgot_logo_icon">
                    <MdSchool />
                </div>
                <div className="userForgot_logo_text">
                    CareerGuide AI
                </div>
            </div>
            <div className="userForgot_card">
                <div className="userForgot_title">
                    Forgot Password
                </div>
                <div className="userForgot_subtitle">
                    Enter your email to reset your password
                </div>
                <div className="userForgot_form">
                    <label className="userForgot_label">Email</label>
                    <input
                        type="email"
                        placeholder="john@example.com"
                        className="userForgot_input"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    {error && (
                        <div style={{ color: "red", marginBottom: "10px" }}>
                            {error}
                        </div>
                    )}
                    <button
                        className="userForgot_button"
                        onClick={handleReset}
                        disabled={loading}
                    >
                        {loading ? "Processing..." : "Reset Password"}
                    </button>
                    <button
                        className="userForgot_back_button"
                        onClick={() => navigate("/")}
                    >
                        Back
                    </button>
                </div>
            </div>
        </div>
    )
}