import "./UserResumeAnalyzer.css"
import { MdUploadFile } from "react-icons/md"
import { useState } from "react"
import axios from "axios"

export default function UserResumeAnalyzer() {
    const [file, setFile] = useState(null)
    const [loading, setLoading] = useState(false)
    const [result, setResult] = useState(null)
    const [error, setError] = useState(null)

    const handleFileChange = async (e) => {
        const selectedFile = e.target.files[0]
        if (!selectedFile) return
        
        setFile(selectedFile)
        setLoading(true)
        setError(null)
        setResult(null)

        const formData = new FormData()
        formData.append("file", selectedFile)

        try {
            // Note: Update backend URL if hosted elsewhere
            const response = await axios.post("http://127.0.0.1:8000/analyze-resume", formData, {
                headers: { "Content-Type": "multipart/form-data" }
            })
            
            if (response.data.error) {
                setError(response.data.error)
            } else {
                setResult(response.data.analysis)
            }
        } catch (err) {
            setError("Failed to connect to the analysis server.")
            console.error(err)
        } finally {
            setLoading(false)
        }
    }

    return (

        <div className="userResume_page">

            <div className="userResume_container">

                <div className="userResume_header">

                    <div className="userResume_icon">
                        <MdUploadFile />
                    </div>

                    <div>

                        <div className="userResume_title">
                            Resume Analyzer
                        </div>

                        <div className="userResume_sub">
                            Get instant AI-powered feedback on your resume
                        </div>

                    </div>

                </div>

                <div className="userResume_card">

                    <div className="userResume_card_title">
                        Upload Your Resume
                    </div>

                    <div className="userResume_formats">
                        Supported formats: PDF (Max 5MB)
                    </div>

                    <label className="userResume_upload_box">

                        <input
                            type="file"
                            className="userResume_input"
                            accept=".pdf"
                            onChange={handleFileChange}
                        />

                        <div className="userResume_upload_icon">
                            <MdUploadFile />
                        </div>

                        <div className="userResume_upload_text">
                            {file ? file.name : "Drop your resume PDF here or click to browse"}
                        </div>

                        <div className="userResume_upload_sub">
                            {loading ? "Analyzing..." : "PDF up to 5MB"}
                        </div>

                    </label>

                    {error && <div style={{color: 'red', marginTop: '15px'}}>{error}</div>}

                    {result && !result.error && (
                        <div style={{marginTop: '30px', textAlign: 'left', background: '#f8f9fa', padding: '20px', borderRadius: '10px'}}>
                            <h3 style={{marginBottom: '15px', color: '#333'}}>Analysis Complete</h3>
                            <div style={{fontSize: '24px', fontWeight: 'bold', color: result.score > 70 ? 'green' : 'orange', marginBottom: '20px'}}>
                                Score: {result.score}/100
                            </div>
                            
                            <h4 style={{color: '#444'}}>Strengths</h4>
                            <ul style={{marginBottom: '15px', paddingLeft: '20px'}}>
                                {result.strengths && result.strengths.map((str, idx) => (
                                    <li key={idx} style={{marginBottom: '5px', color: '#555'}}>{str}</li>
                                ))}
                            </ul>

                            <h4 style={{color: '#444'}}>Areas for Improvement</h4>
                            <ul style={{paddingLeft: '20px'}}>
                                {result.improvements && result.improvements.map((imp, idx) => (
                                    <li key={idx} style={{marginBottom: '5px', color: '#555'}}>{imp}</li>
                                ))}
                            </ul>
                        </div>
                    )}
                    
                    {result && result.error && (
                         <div style={{color: 'red', marginTop: '15px'}}>{result.error}</div>
                    )}

                </div>

            </div>

        </div>

    )

}