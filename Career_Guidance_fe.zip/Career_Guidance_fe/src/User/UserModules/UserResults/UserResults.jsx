import { useEffect, useState } from "react"
import { useLocation, useNavigate } from "react-router-dom"
import axios from "axios"
import "./UserResults.css"

export default function UserResults() {
    const location = useLocation()
    const navigate = useNavigate()
    const email = location.state?.email
    const [careers, setCareers] = useState([])
    const [loading, setLoading] = useState(true)
    const [status, setStatus] = useState("loading")
    useEffect(() => {
        if (email) {
            fetchResults()
        }
    }, [email])
    const fetchResults = async () => {
        try {
            const res = await axios.post(
                "http://127.0.0.1:8000/career-recommendation",
                { Email: email }
            )
            console.log("RESULT DATA:", res.data)
            if (res.data.status === "pending") {
                setStatus("pending")
                setCareers([])
            } else {
                setStatus("completed")
                setCareers(res.data.career_matches || [])
            }
        } catch (err) {
            console.log("Error fetching results:", err)
            setStatus("error")
            setCareers([])
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="userResults_main">
            <div className="userResults_header">
                <div className="userResults_title">
                    Your Career Matches
                </div>
                <div className="userResults_sub">
                    AI-powered recommendations based on your assessment
                </div>
            </div>
            {loading && (
                <div style={{ padding: "20px" }}>
                    Loading results...
                </div>
            )}
            {!loading && status === "pending" && (
                <div style={{ padding: "30px", textAlign: "center" }}>
                    <h3>⚠️ Assessment Not Completed</h3>
                    <p>Please complete your assessment to see career results</p>
                    <button
                        onClick={() =>
                            navigate("/assessment", { state: location.state })
                        }
                        style={{
                            padding: "10px 20px",
                            background: "#4f46e5",
                            color: "#fff",
                            border: "none",
                            borderRadius: "6px",
                            cursor: "pointer",
                            marginTop: "10px"
                        }}
                    >
                        Take Assessment →
                    </button>
                </div>
            )}
            {!loading && status === "error" && (
                <div style={{ padding: "20px", color: "red" }}>
                    Something went wrong
                </div>
            )}
            {!loading && status === "completed" && careers.length === 0 && (
                <div style={{ padding: "20px", color: "red" }}>
                    No results found
                </div>
            )}
            {status === "completed" && careers.length > 0 && (
                <div className="userResults_cards">
                    {careers.map((career, index) => (
                        <div key={index} className="userResults_card">
                            <div className="userResults_left">
                                <div className="userResults_badge">
                                    #{index + 1} Recommended
                                </div>
                                <div className="userResults_job">
                                    {career.job_title}
                                </div>
                                <div className="userResults_desc">
                                    This career matches your profile based on AI analysis.
                                </div>
                                <div className="userResults_skill_title">
                                    Required Skills:
                                </div>
                                <div className="userResults_skills">
                                    {(career.required_skills || []).map((skill, i) => (
                                        <div key={i} className="userResults_skill">
                                            {skill}
                                        </div>
                                    ))}
                                </div>
                                <div className="userResults_why_title">
                                    Why this career fits you
                                </div>
                                <ul className="userResults_why_list">
                                    <li>Based on your answers</li>
                                    <li>Aligned with your skills</li>
                                    <li>Matches your interests</li>
                                </ul>
                                <div className="userResults_steps_title">
                                    Next Steps
                                </div>
                                <ol className="userResults_steps_list">
                                    <li>Learn required skills</li>
                                    <li>Build projects</li>
                                    <li>Practice regularly</li>
                                    <li>Apply for internships/jobs</li>
                                </ol>
                            </div>
                            <div className="userResults_right">
                                <div className="userResults_circle">
                                    {career.match_percentage}%
                                    <div className="userResults_match_text">
                                        Match
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}