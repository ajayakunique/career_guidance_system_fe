import "./UserDashboard.css"
import { MdEmojiEvents, MdTrackChanges, MdDescription } from "react-icons/md"
import { useNavigate, useLocation } from "react-router-dom"
import { useEffect, useState } from "react"
import axios from "axios"

export default function UserDashboard() {
    const navigate = useNavigate()
    const location = useLocation()
    const userName = location.state?.name || "Guest"
    const userEmail = location.state?.email
    const [assessmentStatus, setAssessmentStatus] = useState("loading")
    const [stats, setStats] = useState([
        { title: "Your Degree", value: "Loading..." },
        { title: "Skills", value: "Loading..." },
        { title: "Interests", value: "Loading..." },
        { title: "Assessment", value: "Loading..." }
    ])
    useEffect(() => {
        if (userEmail) {
            fetchDashboard()
            fetchAssessmentStatus()
        }
    }, [userEmail])
    const fetchDashboard = async () => {
        try {
            const res = await axios.post(
                "http://127.0.0.1:8000/dashboard",
                { Email: userEmail }
            )
            const data = res.data.show[0]
            setStats(prev => [
                { title: "Your Degree", value: data?.Your_Degree || "N/A" },
                { title: "Skills", value: data?.Skills || "N/A" },
                { title: "Interests", value: data?.Interests || "N/A" },
                prev[3]
            ])
        } catch (err) {
            console.log("Dashboard error:", err)
        }
    }
    const fetchAssessmentStatus = async () => {
        try {
            const res = await axios.get(
                `http://127.0.0.1:8000/assessment-status/${userEmail}`
            )
            const status = res.data.status
            setAssessmentStatus(status)
            setStats(prev => [
                prev[0],
                prev[1],
                prev[2],
                {
                    title: "Assessment",
                    value:
                        status === "completed"
                            ? "Completed "
                            : "Pending "
                }
            ])
        } catch (err) {
            console.log("Status error:", err)
        }
    }
    const actions = [
        {
            icon: <MdEmojiEvents />,
            title: "Career Results",
            desc: "View recommended career paths",
            path: "/results"
        },
        {
            icon: <MdTrackChanges />,
            title: "Skill Gap Analysis",
            desc: "Identify skills you need",
            path: "/skillgap"
        },
        {
            icon: <MdDescription />,
            title: "Resume Analyzer",
            desc: "Improve your resume quality",
            path: "/resume"
        }
    ]

    return (
        <div className="userDashboard_main_container">
            <div className="userDashboard_header">
                <div className="userDashboard_title">
                    Welcome back, {userName}! 👋
                </div>
                <div className="userDashboard_subtitle">
                    Track your progress and continue your career journey
                </div>
            </div>
            <div className="userDashboard_stats_container">
                {stats.map((item, index) => (
                    <div key={index} className="userDashboard_stat_card">
                        <div className="userDashboard_stat_title">
                            {item.title}
                        </div>
                        <div className="userDashboard_stat_value">
                            {item.value}
                        </div>
                    </div>
                ))}
            </div>
            <div className="userDashboard_assessment_card">
                <div className="userDashboard_assessment_title">
                    Start Your Career Assessment
                </div>
                <div className="userDashboard_assessment_desc">
                    Take our AI-powered assessment to discover your best career path
                </div>
                <button
                    className="userDashboard_assessment_btn"
                    onClick={() =>
                        navigate(
                            assessmentStatus === "completed"
                                ? "/results"
                                : "/assessment",
                            { state: location.state }
                        )
                    }
                >
                    {
                        assessmentStatus === "completed"
                            ? "View Results →"
                            : "Take Assessment"
                    }
                </button>
            </div>
            <div className="userDashboard_quick_title">
                Quick Actions
            </div>
            <div className="userDashboard_actions_container">
                {actions.map((item, index) => (
                    <div
                        key={index}
                        className="userDashboard_action_card"
                        onClick={() => navigate(item.path, { state: location.state })}
                        style={{ cursor: "pointer" }}
                    >
                        <div className="userDashboard_action_icon">
                            {item.icon}
                        </div>
                        <div className="userDashboard_action_title">
                            {item.title}
                        </div>
                        <div className="userDashboard_action_desc">
                            {item.desc}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}