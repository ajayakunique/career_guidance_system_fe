import { useState, useEffect } from "react"
import "./UserAssessment.css"
import { useNavigate, useLocation } from "react-router-dom"
import axios from "axios"

export default function UserAssessment() {
    const navigate = useNavigate()
    const location = useLocation()
    const userEmail = location.state?.email
    const [questions, setQuestions] = useState([])
    const [current, setCurrent] = useState(0)
    const [answers, setAnswers] = useState({})
    const [error, setError] = useState("")
    useEffect(() => {
        fetchQuestions()
    }, [])
    const fetchQuestions = async () => {
        const res = await axios.get("http://127.0.0.1:8000/question")
        // console.log("Questions:", res.data)
        setQuestions(res.data)
    }
    const selectOption = (opt) => {
        setAnswers({ ...answers, [current]: opt })
        setError("")
    }
    const nextQuestion = () => {
        if (!answers[current]) {
            setError("Please select an option")
            return
        }
        if (current < questions.length - 1) {
            setCurrent(current + 1)
        } else {
            handleSubmit()
        }
    }
    const prevQuestion = () => {
        if (current > 0) {
            setCurrent(current - 1)
        }
    }
    const handleSubmit = async () => {
        try {
            if (!userEmail) {
                alert("User not logged in")
                navigate("/")
                return
            }
            const answerList = Object.entries(answers).map(([index, value]) => {
                const q = questions[Number(index)]
                if (!q) {
                    console.log("ERROR: question missing at index", index)
                    return null
                }
                return {
                    question_id: q.id,
                    answer: value
                }
            }).filter(item => item !== null)
            console.log("FINAL DATA:", {
                email: userEmail,
                answers: answerList
            })
            await axios.post("http://127.0.0.1:8000/save-answers",{email: userEmail,answers: answerList})
            console.log("Answers saved successfully")
            navigate("/results", {
                state: { email: userEmail }
            })
        } catch (err) {
            console.log("Submit error:", err)

            alert("Something went wrong while submitting")
        }
    }
    const progress = questions.length > 0
        ? ((current + 1) / questions.length) * 100
        : 0
    if (questions.length === 0) {
        return <div style={{ padding: "20px" }}>Loading questions...</div>
    }

    return (
        <div className="userAssessment_main">
            <div className="userAssessment_content">
                <div className="userAssessment_header">
                    <div className="userAssessment_title">
                        Career Assessment
                    </div>
                    <div className="userAssessment_count">
                        Question {current + 1} of {questions.length}
                    </div>
                </div>
                <div className="userAssessment_progress">
                    <div
                        className="userAssessment_progress_fill"
                        style={{ width: `${progress}%` }}
                    ></div>
                </div>
                <div className="userAssessment_percent">
                    {Math.round(progress)}% Complete
                </div>
                <div className="userAssessment_card">
                    <div className="userAssessment_question">
                        {questions[current]?.question}
                    </div>
                    <div className="userAssessment_options">
                        {questions[current]?.options?.map((opt, index) => (
                            <label key={index} className="userAssessment_option">
                                <input
                                    type="radio"
                                    checked={answers[current] === opt}
                                    onChange={() => selectOption(opt)}
                                />
                                <span>{opt}</span>
                            </label>
                        ))}
                    </div>
                    {error && (
                        <div style={{ color: "red", marginBottom: "10px" }}>
                            {error}
                        </div>
                    )}
                    <div className="userAssessment_buttons">
                        <button
                            className="userAssessment_prev"
                            onClick={prevQuestion}
                            disabled={current === 0}
                        >
                            Previous
                        </button>
                        <button
                            className="userAssessment_next"
                            onClick={nextQuestion}
                        >
                            {current === questions.length - 1 ? "Finish" : "Next Question"}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}