import { useEffect, useState } from "react"
import { useLocation, useNavigate } from "react-router-dom"
import axios from "axios"
import "./UserSkillGap.css"

export default function UserSkillGap() {
    const location = useLocation()
    const navigate = useNavigate()
    const email = location.state?.email
    const [data, setData] = useState([])
    const [loading, setLoading] = useState(true)
    const [status, setStatus] = useState("loading")
    useEffect(() => {
        if (email) {
            fetchSkillGap()
        }
    }, [email])
    const fetchSkillGap = async () => {
        try {
            const studentRes = await axios.get(`http://127.0.0.1:8000/get-student/${email}`)
            const student_id = studentRes.data.student_id
            const res = await axios.get(`http://127.0.0.1:8000/skill-gap/${student_id}`)
            console.log("SKILL GAP:", res.data)
            if (res.data.status === "pending") {
                setStatus("pending")
                setData([])
            } else {
                setStatus("completed")
                setData(res.data.data || [])
            }
        } catch (err) {
            console.log("Error:", err)
            setStatus("error")
            setData([])
        } finally {
            setLoading(false)
        }
    }
    const job = data[0]

    return (
        <div className="userSkillGap_main">
            <div className="userSkillGap_header">
                <div className="userSkillGap_title">
                    Skill Gap Analysis
                </div>
                <div className="userSkillGap_sub">
                    {status === "completed" ? job?.job : ""}
                </div>
            </div>
            {loading && (
                <p style={{ padding: "20px" }}>Loading...</p>
            )}
            {!loading && status === "pending" && (
                <div style={{ padding: "30px", textAlign: "center" }}>
                    <h3>⚠️ Assessment Not Completed</h3>
                    <p>Please complete your assessment to see skill gap analysis</p>
                    <button
                        onClick={() =>
                            navigate("/assessment", { state: location.state })
                        }
                        style={{
                            padding: "10px 20px",
                            background: "#4f46e5",
                            color: "#fff",
                            border: "none",
                            borderRadius: "6px",
                            cursor: "pointer",
                            marginTop: "10px"
                        }}
                    >
                        Take Assessment →
                    </button>
                </div>
            )}
            {!loading && status === "error" && (
                <p style={{ padding: "20px", color: "red" }}>
                    Something went wrong
                </p>
            )}
            {!loading && status === "completed" && !job && (
                <p style={{ padding: "20px", color: "red" }}>
                    No skill gap data found
                </p>
            )}
            {!loading && status === "completed" && job && (
                <div>
                    <div className="userSkillGap_summary">
                        <div className="userSkillGap_card green">
                            <div className="userSkillGap_card_title">
                                Your Skills
                            </div>
                            <div className="userSkillGap_card_text">
                                {job.progress}
                            </div>
                            <div>
                                {job.matching_skills.length > 0
                                    ? job.matching_skills.join(", ")
                                    : "No matching skills"}
                            </div>
                        </div>
                        <div className="userSkillGap_card red">
                            <div className="userSkillGap_card_title">
                                Skills to Learn
                            </div>
                            <div className="userSkillGap_card_text">
                                {job.missing_skills.length} skills needed
                            </div>
                            <div className="userSkillGap_tags">
                                {job.missing_skills.map((skill, i) => (
                                    <div key={i} className="userSkillGap_tag">
                                        {skill}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                    <div className="userSkillGap_roadmap_title">
                        Learning Plan for {job.job}
                    </div>
                    <div className="userSkillGap_roadmap">
                        {job.learning_plan.map((step, i) => (
                            <div key={i} className="userSkillGap_phase">
                                <div className="userSkillGap_phase_header">
                                    <div className="userSkillGap_phase_title">
                                        Step {step.step}: {step.skill}
                                    </div>
                                    <div className="userSkillGap_phase_time">
                                        {step.duration}
                                    </div>
                                </div>
                                <div className="userSkillGap_steps">
                                    <div className="userSkillGap_step">
                                        <div className="userSkillGap_step_title">
                                            How to Learn
                                        </div>
                                        <div className="userSkillGap_step_desc">
                                            {step.how_to_learn}
                                        </div>
                                    </div>
                                    <div className="userSkillGap_step">
                                        <div className="userSkillGap_step_title">
                                            Resources
                                        </div>
                                        <div className="userSkillGap_step_desc">
                                            {step.resources}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    )
}