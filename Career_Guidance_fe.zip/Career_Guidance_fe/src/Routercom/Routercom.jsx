import React from 'react'
import { Route, Routes } from 'react-router-dom'
import UserLogin from '../User/LoginCredentials/UserLogin/UserLogin'
import UserForgotPassword from '../User/LoginCredentials/UserForgotPassword/UserForgotPassword'
import UserResetPassword from '../User/LoginCredentials/UserResetPassword/UserResetPassword'
import UserSignup from '../User/LoginCredentials/UserSignup/UserSignup'
import UserSidebar from '../User/UserSidebar/UserSidebar'
import UserDashboard from '../User/UserModules/UserDashboard/UserDashboard'
import UserAssessment from '../User/UserModules/UserAssessment/UserAssessment'
import UserResults from '../User/UserModules/UserResults/UserResults'
import UserSkillGap from '../User/UserModules/UserSkillGap/UserSkillGap'
import UserResumeAnalyzer from '../User/UserModules/UserResumeAnalyzer/UserResumeAnalyzer'

export default function Routercom() {
    return (
        <Routes>
            <Route path="/" element={<UserLogin />} />
            <Route path="/signup" element={<UserSignup />} />
            <Route path="/forgotpassword" element={<UserForgotPassword />} />
            <Route path="/resetpassword" element={<UserResetPassword />} />
            <Route element={<UserSidebar />}>
            <Route path="/dashboard" element={<UserDashboard />} />
            <Route path="/assessment" element={<UserAssessment />} />
            <Route path="/results" element={<UserResults />} />
            <Route path="/skillgap" element={<UserSkillGap />} />
            <Route path="/resume" element={<UserResumeAnalyzer />} />
            </Route>
        </Routes>
    )
}
